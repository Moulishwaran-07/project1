OTF and TTF: Wonderbar
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net

Need a little fun in your project? Step right up and get your Wonderbar! This mouth watering display font captures the whimsical feel and style of being a kid in the 70's. Basic latin, punctuation, kerning, European accents, diacritics, alternates, stylistic sets, and a few ligatures are included in the full 
version. You can also access the alternates through the glyphs panel or your software program. Due to the loopy uppercase ascenders and descenders glyph overlap is to be expected. Use in a children's book, poster, or packaging. Guaranteed to not rot your teeth!

The full version is available with purchase of a commercial license OR $15 donation via our homepage. This purchase does NOT qualify as commercial license. Please check the included glyph map for complete list of characters before purchasing. Kerning is limited to latin and extended latin. 

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info. I also design custom fonts for
businesses, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 


visit www.sharkshock.net for more and take a bite out of BORING design!

tags: stylish, display, font, typeface, publishing, logo, title, book, cover, company, brand, branding, sans, serif, poster, headline, retro, Wonka, 80's, 70's, movie, movies, film, action, sci-fi, fantasy, childrens, kids, swirl, twirls, whimsical, childlike, kid, loop, loopy, fun, funny, cartoon, chocolate, candy